<template>
  <div id="app">
    <input type="text" v-model="zipcode">
    <button @click="getAdress()">住所自動入力</button>
    <p>Adress:{{address}}</p>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data(){
    return{
      zipcode: null,
      address: null
    }
  },
  methods: {
    async getAdress(){
      const response = await axios.get(`https://apis.postcode-jp.com/api/v4/postcodes/${this.zipcode}?&apiKey=ご自身のAPIキー`);
      // 以下の様なリクエスト方法もございます。
      // axios.メソッド(URLパスパラメータも含む, {params: {パラメータ名: 値}})
      // const response = await axios.get('https://apis.postcode-jp.com/api/v4/postcodes/' + this.zipcode, {
      //   params: {
      //     apiKey: 'ご自身のAPIキー'
      //   }
      // });
      this.address = response.data[0].allAddress;
    }
  }
}
</script>
